# Clean-room checker doorway 0.2-r5

Implement the public checker contract without Bulla Assurance Linker reference
source. Verify the signed trial envelope with the separately supplied coordinator
context. The semantic root is inherited byte-for-byte from r4.

Trial root: `sha256:17e72628d742bfa5583b7a0a4ec681dd72428aedad561224007f1e0c570ab2e6`
