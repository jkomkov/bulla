# Access contract

Permitted materials are the members of this positive-allowlist archive and public
normative clarifications. Reference implementations, generators, mutations, hidden
inputs, and hidden answers are prohibited before source freeze.
