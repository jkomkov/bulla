# FRSL-1 and Interpolant Envelope Format

Status: experimental research format. Problem and package documents remain
`0.1-experimental`; sealed synthesis results are `0.2-experimental`.
It is not a Glyph wire version and is not exported by Bulla's stable API.

## Language

FRSL-1 has:

- finite, non-empty named sorts with named elements;
- equality within one declared sort;
- unary and binary relation symbols;
- `true`, `false`, `not`, `and`, `or`, `implies`, and `iff`;
- bounded `forall` and `exists` over a named finite sort.

It has no functions, arithmetic, floating point, unbounded quantification,
regex, host-language predicates, callbacks, or unknown AST members. Terms are
closed objects containing exactly one of `{"var": NAME}` or
`{"const": NAME}`. Every formula and structure is checked for arity, sort,
binding, and closed-object conformance before it is interpreted.

## Canonical form

Canonical JSON uses sorted object keys and no insignificant whitespace.
Formula canonicalization additionally:

- flattens associative conjunctions and disjunctions;
- sorts and deduplicates their children;
- removes Boolean identities and applies annihilators;
- removes double negation and negated Boolean constants; and
- sorts both sides of `iff`.

This is structural canonicalization, not a decision procedure for logical
equivalence. A package containing a noncanonical formula fails verification;
the verifier never silently rewrites a received package before hashing it.

## SeamProblem

A `SeamProblem` is a closed object containing:

- `signature`: finite sorts and unary/binary relation declarations;
- `local_theories`: one constraint set per distinct owner;
- `overlap_maps`: sort-preserving permutations between declared relations;
- `target_predicate`: the relation to be defined;
- `shared_vocabulary`: the only relations an invented predicate may read;
- `protected_signatures`: owner-indexed relation sets whose declarations are
  pinned into the package;
- `requested_judgment`: `boolean` or `rely_refuse_escalate`;
- `synthesis_policy`: exhaustive model, candidate, alternative, and minimality
  bounds; and
- authority, applicability scope, expiry, and evidence requirements.

The target may not be shared or protected. Unknown owners, relations, sorts,
fields, duplicate vocabulary entries, and ill-sorted overlaps are invalid.

## PredicatePackage

A full package contains one `definition`. A partial package contains both
`rely_when` and `refuse_when`; every other point is explicitly `ESCALATE`.
Each package binds:

- the canonical problem hash;
- owner-local copies of the same decision surface;
- the exact overlap declarations and evidence requirements;
- protected-signature pins;
- authority, scope, and expiry;
- candidate and independent-verifier identities;
- reproducible model, feature, AST-size, and minimality costs; and
- proof or solver-artifact references.

All emitted predicates are restricted to the shared vocabulary. Full packages
must agree with the target at every point of every admissible finite model.
Partial `RELY` may include only target-positive points, partial `REFUSE` may
include only target-negative points, and the two surfaces may not overlap.

`minimality = exact-finite-candidate-space` refers only to exact DNF size over
the declared generated feature set. The verifier recomputes that claim. Any
other formula language or an exceeded candidate bound yields
`minimality = unresolved` rather than a global minimum claim.

At application time an evidence adapter must provide exactly the declared
shared relations. Target and private relations are rejected even if the
predicate would not inspect them. Application replays the package gates before
evaluating `RELY`, `REFUSE`, or the residual `ESCALATE` surface.

## FailureCertificate

Mathematical and operational exits are distinct types:

- `topology_obstruction`: an admissible structure violating a declared overlap;
- `fixed_language_non_definability`: two admissible expansions with the same
  shared reduct and different target truth at one named tuple;
- `non_conservativity`: reserved typed surface for a protected-consequence
  counterexample;
- `non_unique_minimum`: at least two checked exact-minimum packages plus a
  reachable shared structure on which they disagree;
- `resource_limit`: timeout, solver unknown, missing artifact, or exceeded
  bound; and
- `invalid_problem`: malformed or vacuous input.

Resource and invalid-input certificates never verify as mathematical
impossibility. The current engine emits non-conservativity witnesses through
the bounded precedent compiler rather than the M1 synthesis path.

## SynthesisResult

The sealed statuses are:

- `COMPILED`: a checked full definition;
- `PARTIAL`: checked RELY and REFUSE surfaces plus a residual witness;
- `ESCALATE`: a verified objective obstruction or fixed-language pair;
- `CHOICE_REQUIRED`: checked inequivalent exact minima requiring authority;
- `INDETERMINATE`: resource or candidate-backend failure; and
- `INVALID_INPUT`: a problem outside the reference semantics.

`GateReport` has named gluing, conservativity, definability, preserved-refusal,
minimality, and receipt-binding statuses. It deliberately has no Boolean
coercion. Callers must inspect the gates required by the result status.

Result v0.2 also binds a typed cause and next actions. Mathematical exits carry
axis-specific enrichment plans. In particular, a same-reduct countermodel
requires a new jointly authorized observable; more syntax over the same reduct
cannot distinguish it. Resource changes remain operational plans and never
become semantic certificates.

For `CHOICE_REQUIRED`, alternatives are partitioned by their truth behavior on
every bounded protected structure and by a declared cost vector. Different
bytes in one behavior-and-cost class have a deterministic canonical
representative and do not manufacture governance. Multiple cost classes are an
economic choice; multiple behavior classes are a normative choice. Either
requires an authority-bound selection receipt.

## Receipt binding and portability

An invention outcome may be recorded in an unchanged ActionReceipt v0.2 using
`action.type = "bulla.invent"`. The subject binds the problem, aggregate
package/certificate artifact, verifier, and synthesis policy hashes. This does
not make FRSL-1 normative.

Selection and application use ordinary open action types
`bulla.invent.select` and `bulla.invent.apply`. The compilation cache key binds
the problem, protected signatures, synthesis policy, evidence adapter,
verifier, and grammar. Cache reads replay the package and invalidate stale
adapter identities. Application receipts bind the exact input structure,
arguments, package, decision, and policy and can be independently replayed.

The library verifier and `bulla/scripts/verify_invention.py` independently
replay the finite semantics. The standalone checker imports only the Python
standard library, rejects malformed and unknown members, and requires
authority/scope/expiry, refusal, exact-minimality, and problem binding before
accepting a package.

## Observability and refinement profile

`LogicPassport` and `ConservationManifest` are closed, content-addressed
documents that pin the finite semantics, resource envelope, protected meaning,
disclosure, permitted warrants, and authority. An `ObservableOffer` declares a
new unary or binary Boolean relation, its FRSL-1 meaning over the existing
problem, provider, warrant profile, consent subjects, optional expiry, and the
fixed burden vector:

- disclosure units;
- latency milliseconds;
- monetary microunits;
- new authorities;
- institutional dependencies; and
- lifecycle burden.

The planner emits every inclusion-minimal separating subset within a catalog of
at most sixteen offers. Each plan binds the full opposing-pair commitment,
per-offer coverage, exact sufficiency, minimality, componentwise Pareto status,
required consent subjects, predicted pair reduction, and catalog/passport/
manifest hashes. It calls an offer indispensable only when every minimal
sufficient plan contains it.

An `EnrichmentRequest` binds the verified fixed-language certificate and the
offered plans. Signed `EnrichmentResponse` documents are exactly `CONSENT`,
`REFUSE`, `COUNTEROFFER`, or `PROVIDE`. `PROVIDE` must supply exactly one
warranted Boolean fact for every tuple of every selected offered relation; raw
evidence and private model bodies remain out of the artifact.

A `ConstraintAdmission` binds the selected plan, every required response,
warrant class, admitted canonical FRSL-1 constraint, manifest, and authority
epoch. `EnvelopeSnapshot` commits to the effective semantic state and the
RELY/REFUSE/ambiguous partition. `RefinementCertificate` independently checks
state inclusion, prior RELY and REFUSE retention on still-reachable cells,
ambiguity narrowing, authority preservation, and all underlying package gates.

The lifecycle types are `PRESERVE` (same world set), `REFINE` (strict subset in
the same epoch), `REVISE` (new epoch), and `ROUTE` (no mutation and an escalated
case). Same-epoch widening is invalid. The ActionReceipt schema remains
unchanged; the experimental actions are `bulla.enrich.request`,
`bulla.enrich.respond`, `bulla.enrich.apply`, `bulla.envelope.refine`, and
`bulla.term.supersede`.

## Trust boundary

The exhaustive finite semantics is the reference backend. SMTInterpol and
language models are candidate sources only. A solver timeout, `unknown`, parse
failure, pin mismatch, or independently rejected interpolant becomes
`INDETERMINATE`; it never becomes a countermodel or impossibility theorem.

The Lean project proves abstract finite obligations. No verified compiler yet
connects arbitrary FRSL-1 JSON bytes to those Lean definitions, so the current
abstraction-to-code boundary is covered by differential tests rather than a
single end-to-end proof.
